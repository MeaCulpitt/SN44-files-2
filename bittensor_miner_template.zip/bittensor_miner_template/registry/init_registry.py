#!/usr/bin/env python3
"""
registry/init_registry.py

Initialises the agent registry directory for a new mining session.
Run once before starting Claude Code for the first time.

Usage:
    python registry/init_registry.py
    python registry/init_registry.py --element-id manak0/Detect-Person
"""
import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path


REGISTRY_DIR = Path(__file__).parent


def init_agent_registry():
    """Create agent_registry.jsonl if it doesn't exist."""
    path = REGISTRY_DIR / "agent_registry.jsonl"
    if path.exists():
        lines = path.read_text().strip().split("\n")
        n = len([l for l in lines if l.strip()])
        print(f"  agent_registry.jsonl: exists ({n} entries)")
        return
    path.write_text("")
    print("  agent_registry.jsonl: created (empty)")


def init_progress():
    """Create progress.txt with session header."""
    path = REGISTRY_DIR / "progress.txt"
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    if path.exists():
        print(f"  progress.txt: exists ({path.stat().st_size} bytes)")
        return
    path.write_text(
        f"# Bittensor Miner Agent Registry\n"
        f"# Initialised: {ts}\n"
        f"# Format: [WN] LOOP -- details\n"
        f"# Append-only. Never delete entries.\n"
        f"\n"
        f"[W000] INIT -- Registry created. No deployments yet. "
        f"Window gate: 0 windows since last deployment.\n"
    )
    print("  progress.txt: created")


def init_shadow_accuracy():
    """Create shadow_accuracy.json with generic prior."""
    path = REGISTRY_DIR / "shadow_accuracy.json"
    if path.exists():
        print("  shadow_accuracy.json: exists")
        return
    data = {
        "_comment": "Shadow evaluator calibration state. Updated by agent after each mutation outcome.",
        "model": "generic",
        "base_accuracy": 0.85,
        "decay_per_window": 0.97,
        "current_accuracy": 0.85,
        "buffer_age_windows": 0,
        "n_mutation_outcomes": 0,
        "last_updated_window": 0,
        "r2_vs_generic": None,
        "use_learned_model": False,
        "mutation_outcomes": []
    }
    path.write_text(json.dumps(data, indent=2))
    print("  shadow_accuracy.json: created (generic prior)")


def init_mutations():
    """Create mutations.jsonl if it doesn't exist."""
    path = REGISTRY_DIR / "mutations.jsonl"
    if path.exists():
        lines = path.read_text().strip().split("\n")
        n = len([l for l in lines if l.strip()])
        print(f"  mutations.jsonl: exists ({n} entries)")
        return
    path.write_text("")
    print("  mutations.jsonl: created (empty)")


def init_buffer_metadata():
    """Create buffer_metadata.json."""
    path = REGISTRY_DIR / "buffer_metadata.json"
    if path.exists():
        print("  buffer_metadata.json: exists")
        return
    data = {
        "_comment": "Replay buffer state. Updated by agent when buffer is built or rebuilt.",
        "state": "UNBUILT",
        "n_frames": 0,
        "n_clips": 0,
        "build_window": None,
        "last_rebuild_window": None,
        "age_windows": 0,
        "accuracy": None,
        "model_hash_at_build": None,
        "pgt_recipe_hash_at_build": None,
        "invalidated_by": None
    }
    path.write_text(json.dumps(data, indent=2))
    print("  buffer_metadata.json: created (UNBUILT state)")


def check_subnet_config():
    """Verify subnet_config.json exists one level up."""
    config_path = REGISTRY_DIR.parent / "subnet_config.json"
    if not config_path.exists():
        print(f"  WARNING: subnet_config.json not found at {config_path}")
        print("  Copy and fill in the template before starting Claude Code.")
        return False
    try:
        data = json.loads(config_path.read_text())
        subnet_id = data.get("subnet_id", "?")
        elements = list(data.get("elements", {}).keys())
        print(f"  subnet_config.json: OK (subnet={subnet_id}, elements={elements})")
        return True
    except Exception as e:
        print(f"  subnet_config.json: INVALID JSON -- {e}")
        return False


def check_claude_md():
    """Verify CLAUDE.md exists."""
    claude_path = REGISTRY_DIR.parent / "CLAUDE.md"
    agents_path = REGISTRY_DIR.parent / "AGENTS.md"
    if claude_path.exists():
        print(f"  CLAUDE.md: found")
        return True
    if agents_path.exists():
        print(f"  AGENTS.md: found (Claude Code will use this)")
        return True
    print("  WARNING: Neither CLAUDE.md nor AGENTS.md found.")
    print("  Claude Code will not have mining agent instructions.")
    return False


def check_alignment_tests():
    """Verify alignment tests exist."""
    test_dir = REGISTRY_DIR.parent / "scoring_alignment" / "tests"
    if not test_dir.exists():
        print("  scoring_alignment/tests/: not found")
        print("  Run scoring alignment setup before first deployment.")
        return False
    test_files = list(test_dir.glob("test_*.py"))
    print(f"  scoring_alignment/tests/: {len(test_files)} test files")
    return len(test_files) > 0


def append_progress(message: str):
    path = REGISTRY_DIR / "progress.txt"
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    with open(path, "a") as f:
        f.write(f"[INIT {ts}] {message}\n")


def main():
    parser = argparse.ArgumentParser(description="Initialise miner agent registry")
    parser.add_argument("--element-id", help="Element ID being mined (optional)")
    parser.add_argument("--force", action="store_true", help="Reinitialise even if exists")
    args = parser.parse_args()

    print("=" * 60)
    print("Bittensor Miner Agent Registry Initialiser")
    print("=" * 60)
    print()

    print("Checking prerequisites:")
    config_ok = check_subnet_config()
    claude_ok = check_claude_md()
    tests_ok  = check_alignment_tests()
    print()

    print("Initialising registry files:")
    REGISTRY_DIR.mkdir(exist_ok=True)
    init_agent_registry()
    init_progress()
    init_shadow_accuracy()
    init_mutations()
    init_buffer_metadata()
    print()

    if args.element_id:
        append_progress(f"Registry initialised for element: {args.element_id}")
        print(f"Element: {args.element_id}")

    print("=" * 60)
    if config_ok and claude_ok:
        print("Registry ready. Start Claude Code in this directory.")
        print()
        print("Suggested first prompt:")
        print('  "Read CLAUDE.md and subnet_config.json, then run the')
        print('   session start checklist from CLAUDE.md Section 11."')
    else:
        print("Prerequisites missing (see warnings above).")
        print("Fix before starting Claude Code.")
    print("=" * 60)


if __name__ == "__main__":
    main()
