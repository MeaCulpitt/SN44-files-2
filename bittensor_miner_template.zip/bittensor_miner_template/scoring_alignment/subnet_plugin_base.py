"""
scoring_alignment/subnet_plugin_base.py

Base class that any subnet-specific scoring alignment plugin must implement.
The generic test runner calls these methods -- the subnet fills in the details.

For SN44 Detect-Person / Detect-Vehicle:
  See scoring_alignment/sn44_plugin.py

For a new subnet:
  1. Copy sn44_plugin.py as your_subnet_plugin.py
  2. Implement all abstract methods
  3. Register in scoring_alignment/run_all_tests.py
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ScoringResult:
    """What every subnet's scoring function must return."""
    # Per-pillar scores (pillar_name -> score in [0,1])
    pillar_scores: dict[str, float]
    # Weighted sum of pillars
    total_weighted: float
    # After baseline gate and beta
    gated_score: float
    # Whether the gated score is above baseline_theta
    above_theta: bool
    # Raw diagnostics for debugging
    diagnostics: dict[str, Any]


@dataclass
class ParsedOutput:
    """The miner's output after parsing, before scoring."""
    # The parsed predictions in whatever form the subnet uses
    predictions: Any
    # Frame/item count that was parsed
    n_items: int
    # Whether any items were silently dropped during parsing
    n_dropped: int
    # The raw output that was parsed
    raw: Any


class SubnetPlugin(ABC):
    """
    Abstract base for subnet-specific scoring alignment plugins.

    Each subnet implements this to allow the generic framework to:
    - Parse miner output the same way the validator does
    - Score miner output against synthetic ground truth
    - Verify alignment between miner output and scoring expectations
    """

    # ── Required metadata ─────────────────────────────────────────────────────

    @property
    @abstractmethod
    def subnet_id(self) -> int:
        """The Bittensor subnet ID (e.g. 44)."""
        ...

    @property
    @abstractmethod
    def element_ids(self) -> list[str]:
        """List of element IDs this plugin covers."""
        ...

    @property
    @abstractmethod
    def active_pillars(self) -> dict[str, dict[str, float]]:
        """
        Active pillars and weights per element_id.
        e.g. {"manak0/Detect-Person": {"map50": 0.65, "false_positive": 0.35}}
        """
        ...

    # ── Required: output parsing ──────────────────────────────────────────────

    @abstractmethod
    def parse_miner_output(self, raw_output: dict,
                           element_id: str) -> ParsedOutput:
        """
        Parse miner output exactly as the validator does.
        Must silently drop invalid items (not raise exceptions).
        Must count dropped items in ParsedOutput.n_dropped.

        This is the function most likely to have bugs -- class mapping,
        frame ID alignment, missing fields all manifest here.
        """
        ...

    # ── Required: ground truth generation ────────────────────────────────────

    @abstractmethod
    def make_synthetic_gt(self, n_items: int,
                           element_id: str, **kwargs) -> Any:
        """
        Generate synthetic ground truth for testing.
        Must match the format the validator's scoring function expects.
        """
        ...

    @abstractmethod
    def make_synthetic_prediction(self, gt: Any, element_id: str,
                                   quality: float = 0.8,
                                   n_extra_fp: int = 0,
                                   conf: float = 0.9) -> dict:
        """
        Generate synthetic miner output for testing.
        quality: how well the prediction matches GT (1.0 = perfect)
        n_extra_fp: number of spurious detections to add
        """
        ...

    # ── Required: scoring ─────────────────────────────────────────────────────

    @abstractmethod
    def score(self, parsed_output: ParsedOutput, gt: Any,
              element_id: str) -> ScoringResult:
        """
        Score parsed miner output against ground truth.
        Must exactly replicate the validator's scoring logic.
        """
        ...

    # ── Required: gate computation ────────────────────────────────────────────

    @abstractmethod
    def weight_score(self, pillar_scores: dict[str, float],
                     element_id: str) -> ScoringResult:
        """
        Apply manifest gating: baseline_theta, delta_floor, beta.
        Must exactly replicate Element.weight_score() from manifest.py.
        """
        ...

    # ── Required: alignment checks ────────────────────────────────────────────

    @abstractmethod
    def get_alignment_checks(self) -> list[dict]:
        """
        Return the list of alignment checks for this subnet.
        Each check is a dict with:
          - id: int
          - priority: "CRITICAL" | "HIGH" | "MEDIUM"
          - description: str
          - test_function: callable() -> None (raises AssertionError on fail)
        """
        ...

    # ── Optional: RTF gate ────────────────────────────────────────────────────

    def compute_rtf(self, p95_latency_ms: float,
                    service_rate_fps: float) -> float:
        """
        Compute Real-Time Factor.
        Override if your subnet uses a different RTF formula.
        Default: SN44 formula (p95_ms / 10000) * (service_rate_fps / 5)
        """
        return (p95_latency_ms / 10000.0) * (service_rate_fps / 5.0)

    def rtf_passes(self, p95_latency_ms: float,
                   service_rate_fps: float) -> bool:
        return self.compute_rtf(p95_latency_ms, service_rate_fps) <= 1.0

    # ── Optional: copy-miner check ────────────────────────────────────────────

    def check_copy_miner_similarity(
        self,
        your_scores: dict[str, float],
        winner_scores: dict[str, float],
        delta_abs: float = 0.02,
        delta_rel: float = 0.05,
        min_common: int = 5,
    ) -> tuple[bool, dict]:
        """
        Check if per-challenge scores are too similar to the winner.
        Default implementation matches scoring.py are_similar_by_challenges.
        Override if your subnet uses different similarity logic.
        """
        common = []
        for cid in set(your_scores) | set(winner_scores):
            s1 = float(your_scores.get(cid, 0.0) or 0.0)
            s2 = float(winner_scores.get(cid, 0.0) or 0.0)
            if abs(s1) > 1e-9 and abs(s2) > 1e-9:
                common.append((cid, s1, s2))

        if len(common) < min_common:
            return False, {"reason": "insufficient_common", "n_common": len(common)}

        n_diff = 0
        for cid, s1, s2 in common:
            threshold = max(delta_abs, delta_rel * max(abs(s1), abs(s2)))
            if abs(s1 - s2) > threshold:
                n_diff += 1

        is_similar = n_diff == 0
        return is_similar, {
            "n_common": len(common),
            "n_differentiated": n_diff,
            "pct_differentiated": n_diff / len(common),
        }

    # ── Convenience: full pipeline ────────────────────────────────────────────

    def score_end_to_end(self, raw_output: dict, gt: Any,
                          element_id: str) -> ScoringResult:
        """
        Parse -> score -> gate. Returns final gated result.
        Convenience wrapper for tests.
        """
        parsed = self.parse_miner_output(raw_output, element_id)
        return self.score(parsed, gt, element_id)
