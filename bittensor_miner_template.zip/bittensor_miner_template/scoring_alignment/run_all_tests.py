#!/usr/bin/env python3
"""
scoring_alignment/run_all_tests.py

Generic test runner for any Bittensor subnet miner scoring alignment.
Discovers the subnet plugin, runs its alignment checks, reports results.

Usage:
    python scoring_alignment/run_all_tests.py
    python scoring_alignment/run_all_tests.py --check 1
    python scoring_alignment/run_all_tests.py --verbose
    python scoring_alignment/run_all_tests.py --update-progress

For SN44 specifically, also runs the fixed test files:
    python scoring_alignment/run_all_tests.py --subnet sn44
"""
import sys
import os
import json
import argparse
import subprocess
import importlib.util
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).parent.parent
REGISTRY = ROOT / "registry"
PROGRESS_FILE = REGISTRY / "progress.txt"


def load_subnet_config() -> dict:
    config_path = ROOT / "subnet_config.json"
    if not config_path.exists():
        print("ERROR: subnet_config.json not found.")
        sys.exit(1)
    return json.loads(config_path.read_text())


def load_plugin(subnet_id: int):
    """
    Try to load the subnet-specific plugin.
    Looks for: scoring_alignment/sn{subnet_id}_plugin.py
    Falls back to: scoring_alignment/plugin.py
    """
    candidates = [
        Path(__file__).parent / f"sn{subnet_id}_plugin.py",
        Path(__file__).parent / "plugin.py",
    ]
    for path in candidates:
        if path.exists():
            spec = importlib.util.spec_from_file_location("plugin", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            # Find the SubnetPlugin subclass
            from scoring_alignment.subnet_plugin_base import SubnetPlugin
            for name in dir(mod):
                obj = getattr(mod, name)
                try:
                    if (isinstance(obj, type) and
                            issubclass(obj, SubnetPlugin) and
                            obj is not SubnetPlugin):
                        return obj()
                except Exception:
                    continue
    return None


def run_test_file(filepath: str) -> tuple[bool, str, int, int]:
    """Run a test file, return (passed, output, n_pass, n_fail)."""
    result = subprocess.run(
        [sys.executable, str(filepath)],
        capture_output=True, text=True,
        cwd=str(ROOT),
    )
    output = result.stdout + (result.stderr or "")
    passed = result.returncode == 0
    n_pass = output.count("  PASS  ")
    n_fail = output.count("  FAIL  ") + output.count("  ERROR ")
    return passed, output, n_pass, n_fail


def run_sn44_tests(check_num=None, verbose=False) -> dict:
    """Run SN44-specific test files."""
    test_dir = Path(__file__).parent / "tests"
    if not test_dir.exists():
        # Try the miner_ralph tests directory
        test_dir = ROOT.parent / "miner_ralph" / "tests"

    sn44_tests = {
        1: "test_class_mapping.py",
        2: "test_frame_alignment.py",
        3: "test_confidence_and_gate.py",
        4: "test_box_validity_and_rtf.py",
        5: "test_copy_miner_differentiation.py",
    }

    results = {}
    checks_to_run = {check_num: sn44_tests[check_num]} if check_num else sn44_tests

    for num, filename in checks_to_run.items():
        filepath = test_dir / filename
        if not filepath.exists():
            results[num] = ("SKIP", "", 0, 0)
            continue
        ok, output, n_pass, n_fail = run_test_file(filepath)
        results[num] = ("PASS" if ok else "FAIL", output, n_pass, n_fail)
        if verbose and not ok:
            for line in output.split("\n"):
                if line.strip() and not line.strip().startswith("  PASS"):
                    print(f"    {line}")

    return results


def run_plugin_checks(plugin, check_num=None, verbose=False) -> dict:
    """Run checks from a subnet plugin."""
    checks = plugin.get_alignment_checks()
    if check_num:
        checks = [c for c in checks if c["id"] == check_num]

    results = {}
    for check in checks:
        try:
            check["test_function"]()
            results[check["id"]] = ("PASS", check["description"],
                                     check["priority"], 1, 0)
        except AssertionError as e:
            results[check["id"]] = ("FAIL", str(e), check["priority"], 0, 1)
        except Exception as e:
            results[check["id"]] = ("ERROR", str(e), check["priority"], 0, 1)

    return results


def append_progress(lines: list[str]) -> None:
    if not PROGRESS_FILE.exists():
        return
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    with open(PROGRESS_FILE, "a") as f:
        f.write(f"\n# --- run_all_tests.py {ts} ---\n")
        for line in lines:
            f.write(line + "\n")


def print_summary(results: dict, config: dict) -> bool:
    """Print summary and return True if all passed."""
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)

    priorities = {
        "CRITICAL": "\033[91m",  # red
        "HIGH": "\033[93m",      # yellow
        "MEDIUM": "\033[94m",    # blue
        "PASS": "\033[92m",      # green
        "RESET": "\033[0m",
    }

    all_pass = True
    critical_fail = False
    total_pass = 0
    total_fail = 0

    for check_num in sorted(results.keys()):
        row = results[check_num]
        if len(row) == 4:  # from run_sn44_tests
            status, _, n_pass, n_fail = row
            priority = "CRITICAL" if check_num <= 2 else "HIGH" if check_num <= 4 else "MEDIUM"
            desc = ["", "Class mapping", "Frame alignment",
                    "Confidence + FP + gate", "Box validity + RTF",
                    "Copy-miner differentiation"].get(check_num, "")
        else:  # from run_plugin_checks
            status, desc, priority, n_pass, n_fail = row

        flag = "✓" if status == "PASS" else ("✗" if status in ("FAIL", "ERROR") else "?")
        print(f"  {flag} CHECK {check_num} [{priority}]: {status}  ({n_pass}✓ {n_fail}✗)  {desc}")

        if status in ("FAIL", "ERROR"):
            all_pass = False
            if priority == "CRITICAL":
                critical_fail = True
        total_pass += n_pass
        total_fail += n_fail

    print()
    print(f"  Total: {total_pass} tests passed, {total_fail} failed")
    print()

    if all_pass:
        print("  All checks passing.")
        print("  Miner output correctly aligned with scoring functions.")
        print("  Next: deploy and verify shard log matches local predictions.")
    elif critical_fail:
        print("  CRITICAL failures -- fix CHECK 1 or 2 first.")
        print("  These cause silent score loss with no visible error.")
    else:
        print("  Non-critical failures. Address in priority order.")

    return all_pass


def main():
    parser = argparse.ArgumentParser(
        description="Bittensor miner scoring alignment test runner")
    parser.add_argument("--check", type=int, help="Run only this check number")
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--update-progress", action="store_true")
    parser.add_argument("--subnet", default="sn44",
                        help="Subnet ID string (default: sn44)")
    args = parser.parse_args()

    config = load_subnet_config()
    subnet_id = config.get("subnet_id", 44)

    print("=" * 70)
    print(f"Bittensor SN{subnet_id} Scoring Alignment Check Runner")
    print(f"Subnet: {config.get('subnet_name', 'Unknown')}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    print()

    # Try to load subnet plugin
    plugin = load_plugin(subnet_id)

    if plugin:
        print(f"Plugin: {type(plugin).__name__}")
        results = run_plugin_checks(plugin, args.check, args.verbose)
    else:
        # Fall back to SN44 test files
        print(f"No plugin found for SN{subnet_id} -- using SN44 test files")
        results = run_sn44_tests(args.check, args.verbose)

    print()
    all_pass = print_summary(results, config)

    if args.update_progress:
        lines = []
        for check_num, row in sorted(results.items()):
            status = row[0]
            n_pass = row[-2]
            n_fail = row[-1]
            lines.append(
                f"[CHECK {check_num}] {status} -- "
                f"{n_pass} pass, {n_fail} fail"
            )
        append_progress(lines)
        print(f"\n  Progress written to {PROGRESS_FILE}")

    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
