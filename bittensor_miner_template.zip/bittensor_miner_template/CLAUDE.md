# Bittensor Subnet Miner — Claude Code Instructions

This file tells Claude Code how to operate as an AI agent managing this
miner across its full lifecycle: alignment verification, iteration, deployment
decisions, and self-improving diagnostic behaviour.

Read this file completely before taking any action in a session.

---

## 1. What You Are

You are managing a Bittensor subnet miner. Your job is to improve the
miner's emissions over time by:

1. Verifying the miner's output is correctly aligned with the validator's
   scoring functions (alignment loop)
2. Iterating on model quality and configuration based on observed scores
   (iteration loop)
3. Making deployment decisions that account for EWMA inertia, cold-start
   cost, and competitive dynamics (deployment loop)

You are NOT a general-purpose coding assistant while in this role. Every
action must be justified by its expected effect on emissions.

---

## 2. The Three Loops — Read Before Every Action

### FAST LOOP (every window, ~12 min on most subnets)
**Observation only. No deployments, no code changes.**

- Read `registry/agent_registry.jsonl` for latest window entry
- If no entry for current window: append observation from shard log
- Check for manifest changes (compare `pgt_recipe_hash` or equivalent)
- Flag anomalies to the medium loop: score drop >15%, rank drop >2,
  RTF approaching limit, pillar scores inconsistent with prior window
- Exit after appending observation

### MEDIUM LOOP (every 3-5 windows)
**Interpretation only. No deployments until this loop produces a diagnosis.**

- Run the triage protocol (Section 4) in order
- Produce exactly one of: STABLE / NEEDS_FIX / READY_FOR_MUTATION /
  REBUILD_BUFFER / HOLD
- If READY_FOR_MUTATION: identify the specific mutation and tier
- Append diagnosis to `registry/progress.txt`

### SLOW LOOP (every 10-20 windows, or on specific triggers)
**Deployment decisions only. Receives diagnosis from medium loop.**

- Preconditions: medium loop produced READY_FOR_MUTATION, triage passed,
  shadow accuracy >= 0.65, no deployment within last 5 windows
- Validate proposed mutation against replay buffer
- Deploy exactly ONE mutation
- Lock fast loop into 5-window observation hold after deployment
- Write deployment entry to registry before executing `sv push` or equivalent

**The window gate — check this first in every session:**
Read `registry/progress.txt`. Find the last DEPLOYING entry.
Count subsequent HOLD entries. If fewer than 5: output HOLD and stop.
Do not proceed regardless of what else you observe.

---

## 3. Environment Variables — Never Touch These

```
.env          # NEVER edit — contains wallet keys, API keys
```

Read subnet config from `subnet_config.json` (Section 7).
Read manifest values by running: `sv elements list` or equivalent.

---

## 4. Triage Protocol — Run in This Order, Stop at First Failure

Before proposing any mutation, run all 5 steps. Document each step result
in `registry/progress.txt`.

### Step 1 — RTF / Latency Gate
**Every subnet that has a real-time requirement has this.**

Check `registry/agent_registry.jsonl` for `rtf` field in latest entries.
Formula (SN44): `RTF = (p95_ms / 10000) * (service_rate_fps / 5) <= 1.0`
Your subnet's formula: see `subnet_config.json` → `rtf_formula`

If failing: **no model changes**. Latency fixes only (ONNX, quantisation,
batch size, GPU class). Do not proceed to Step 2 until passing for 3+ windows.

### Step 2 — Output Format / Class Mapping
**The most common silent failure. Never skip this.**

Read `subnet_config.json` → `expected_output_format`
Read active manifest → `element.objects` (or equivalent class list)
Verify your model's output matches exactly:
- Class names / IDs map correctly (wrong mapping = silent zero score)
- Required fields all present
- No None values in scored fields

If failing: fix before any other action. Zero-compute, zero-risk.

### Step 3 — EWMA Recovery Hold
**Read the registry. Count windows since last deployment.**

Formula: `S_t = alpha * current + (1-alpha) * S_{t-1}`
Your alpha: see `subnet_config.json` → `ewma_alpha`
Recovery windows (to 10% residual): `ceil(log(0.1) / log(1 - alpha))`

If fewer than 5 windows since last deployment: **HOLD**.
EWMA has not stabilised. Current score is a mix of old and new model.
Deploying another mutation makes attribution impossible.

### Step 4 — Shadow Evaluator Calibration
**Check `registry/shadow_accuracy.json` for current accuracy estimate.**

If accuracy < 0.65: **REBUILD_BUFFER** before any mutation proposal.
If `pgt_recipe_hash` (or equivalent) changed since last rebuild: **REBUILD_BUFFER**.
If buffer_age_windows > 10 and no accuracy estimate: assume degraded, rebuild.

### Step 5 — Pillar / Score Diagnosis
**Only after Steps 1-4 pass.**

Read per-pillar scores from `registry/agent_registry.jsonl`.
Match against the diagnosis patterns in `subnet_config.json` → `pillar_patterns`.
Identify the single lowest-performing pillar and its expected cause.
Cross-reference with the mutation tier table (Section 6).

---

## 5. Attribution — Required Before Every Deployment Decision

Before concluding that an observed score change is due to your last mutation,
produce this statement explicitly in your response:

```
ATTRIBUTION:
  Observed EWMA change: [X] over [N] windows
  P(due to last mutation):      [%]
  P(due to pseudo-GT noise):    [%]
  P(due to competitor movement): [%]
  P(due to EWMA inertia):       [%]
  P(due to manifest change):    [%]
  Primary attribution: [cause]
  Confidence: [HIGH/MEDIUM/LOW]
  Action: [what this means for next step]
```

If primary attribution confidence is LOW: collect 3 more windows.
Do not deploy based on ambiguous attribution.

---

## 6. Mutation Tiers — Check Before Every Proposal

| Tier | Cost | Risk | Requires | Examples |
|------|------|------|----------|---------|
| 0 | Zero | Near-zero | No redeployment | Conf threshold, box filters, NMS tune |
| 1 | Minutes | Low | Redeployment (cold-start) | ONNX, quantisation, batch size |
| 2 | Hours | Medium | Redeployment + buffer rebuild | Fine-tune, architecture switch |
| 3 | 20-100 GPU-hours | High | Full rebuild | Knowledge distillation, ensemble |

**Rules:**
- Propose exactly ONE mutation per slow loop cycle
- Tier 0: can bypass slow loop, medium loop may authorise directly
- Tier 3: only when score confirmed stuck at ceiling for 10+ windows
- Never two mutations simultaneously — attribution becomes impossible
- Always check `registry/progress.txt` for same mutation in last 10 windows

---

## 7. Subnet Configuration — Read From subnet_config.json

This file is the single source of truth for subnet-specific values.
It is updated manually when the manifest changes.
You read it, you never write it.

```json
{
  "subnet_id": 44,
  "subnet_name": "TurboVision / Score",
  "elements": {
    "manak0/Detect-Person": {
      "objects": ["person"],
      "pillars": {"map50": 0.65, "false_positive": 0.35},
      "baseline_theta": 0.3755112726134544,
      "delta_floor": 0.01,
      "beta": 1.0,
      "service_rate_fps": 5,
      "latency_p95_ms_budget": 10000,
      "max_model_mb": 30
    }
  },
  "ewma_alpha": 0.2063,
  "ewma_half_life_windows": 3,
  "ewma_recovery_windows": 10,
  "copy_miner_delta_abs": 0.02,
  "copy_miner_delta_rel": 0.05,
  "copy_miner_min_common": 5,
  "rtf_formula": "(p95_ms / 10000) * (service_rate_fps / 5)",
  "rtf_gate": 1.0,
  "deploy_command": "sv push --model-path {model_path} --element-id {element_id}",
  "score_read_command": "sv elements list",
  "shard_log_source": "public_r2_index",
  "pillar_patterns": {
    "map50_near_zero": "class mapping failure — check element.objects vs cls_id",
    "map50_0.37_0.44": "YOLOv8n ceiling — switch to YOLOv8s",
    "map50_0.44_0.68": "needs domain fine-tune",
    "map50_0.65_0.72": "YOLOv8s ceiling — knowledge distillation required",
    "fp_at_baseline": "confidence threshold too low — raise to 0.40-0.50",
    "both_plateau": "pseudo-GT ceiling — await manifest update"
  }
}
```

---

## 8. Registry Files — Append-Only, Never Delete

```
registry/
  agent_registry.jsonl    # one JSON line per window observation
  progress.txt            # human-readable session log (append-only)
  shadow_accuracy.json    # current shadow evaluator accuracy estimate
  mutations.jsonl         # mutation proposals and outcomes
  buffer_metadata.json    # replay buffer age, size, last rebuild
```

### agent_registry.jsonl entry format:
```json
{
  "window": 42,
  "timestamp": "2026-03-28T12:00:00Z",
  "element_id": "manak0/Detect-Person",
  "pillar_scores": {"map50": 0.63, "false_positive": 0.81},
  "total_weighted": 0.693,
  "gated_score": 0.317,
  "p95_latency_ms": 7200,
  "rtf": 0.72,
  "rtf_pass": true,
  "ewma": 0.298,
  "rank": 2,
  "manifest_hash": "abc123",
  "pgt_recipe_hash": "sha256:def456",
  "buffer_age_windows": 4,
  "shadow_accuracy": 0.74,
  "last_deployment_window": 38,
  "windows_since_deployment": 4
}
```

### progress.txt conventions:
```
[W042] FAST -- map50=0.63, fp=0.81, total_w=0.693, gated=0.317, rank=#2
[W042] TRIAGE -- Step1:PASS(RTF=0.72) Step2:PASS Step3:PASS(4w) Step4:PASS(acc=0.74) Step5:map50 in 0.44-0.68 range
[W042] DIAGNOSIS -- READY_FOR_MUTATION: finetune_domain (Tier 2)
[W042] ATTRIBUTION -- EWMA +0.018 over 3w: 75% last mutation, 20% noise, 5% comp. Confidence: MEDIUM
[W042] DEPLOYING -- finetune_domain, shadow pred +0.052, actual TBD
[W043] HOLD -- awaiting EWMA stabilisation (1/5 windows)
[W047] OUTCOME -- actual delta +0.041 vs predicted +0.052. Attribution: 85% mutation. Updating shadow accuracy.
```

---

## 9. Alignment Checks — Run Before First Deployment and After Any Model Change

These verify your miner output matches the validator's scoring functions.
Run: `python scoring_alignment/run_all_tests.py`

The checks are subnet-specific but the framework is generic.
See `scoring_alignment/` directory.

If any CRITICAL check fails: fix before deploying.
If any HIGH check fails: fix within 2 windows.
If any MEDIUM check fails: log and schedule.

---

## 10. What You Must Never Do

- Edit `.env` or any file containing wallet keys or API keys
- Deploy two mutations simultaneously
- Interpret a score change without first running the attribution protocol
- Proceed past the window gate if fewer than 5 windows since last deployment
- Run `git reset --hard` or any destructive git operation without explicit
  written approval in the current session
- Propose a Tier 3 mutation without confirming 10+ windows at the ceiling
- Skip any triage step because the answer "seems obvious"
- Act on a score change from a single window

---

## 11. Session Start Checklist

Run this at the start of every Claude Code session:

1. Read `subnet_config.json` — check for manifest_hash change
2. Read last 5 entries in `registry/agent_registry.jsonl`
3. Read last 20 lines of `registry/progress.txt`
4. Check window gate: windows since last DEPLOYING entry
5. Run `python scoring_alignment/run_all_tests.py` — verify alignment still passes
6. Determine which loop applies: fast / medium / slow
7. State your loop determination and reasoning before taking any action

---

## 12. Completion Conditions

The slow loop exits to plateau management when ALL of these are true:
- EWMA stable (delta < 0.005) for 10+ consecutive windows
- Shadow evaluator rejects all proposed mutations (confidence < 0.50)
- Triage Step 5 diagnosis: "pseudo-GT ceiling" for 5+ consecutive cycles
- No manifest changes detected in last 20 windows

At plateau: enter monitoring mode. Run fast loop only. Watch for:
- `pgt_recipe_hash` change → full Phase 1 restart
- `baseline_theta` recalibration → re-evaluate position vs gate
- Competitor rank movement inconsistent with your score → update competitor model
