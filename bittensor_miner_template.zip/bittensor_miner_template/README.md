# Bittensor Miner Agent Template

A Claude Code agent framework for Bittensor subnet mining.
Generalises from SN44 (TurboVision / Score) to any subnet.

## What This Is

A set of files you drop into your miner repository that tell Claude Code
how to operate as an AI agent managing the miner: alignment verification,
iteration decisions, deployment gating, and self-improvement over time.

The framework is in two layers:

**Generic core** (works on any subnet):
- `CLAUDE.md` — Claude Code instructions: the three-loop architecture,
  triage protocol, attribution requirement, mutation tiers, registry format
- `subnet_config.json` — subnet-specific values Claude Code reads
- `registry/` — append-only operational logs
- `scoring_alignment/subnet_plugin_base.py` — interface any subnet implements
- `scoring_alignment/run_all_tests.py` — generic test runner

**SN44 reference implementation** (the concrete example):
- `miner_ralph/` — complete scoring alignment test suite for
  `manak0/Detect-Person` and `manak0/Detect-detect-vehicle`
- 46 tests covering all active scoring paths

## Directory Structure

```
your_miner_repo/
├── CLAUDE.md                          ← Claude Code reads this first
├── subnet_config.json                 ← Subnet-specific values (you fill in)
├── miner.py                           ← Your miner code
├── registry/
│   ├── init_registry.py               ← Run once to initialise
│   ├── agent_registry.jsonl           ← Per-window observations (append-only)
│   ├── progress.txt                   ← Session log (append-only)
│   ├── shadow_accuracy.json           ← Shadow evaluator calibration state
│   ├── mutations.jsonl                ← Mutation proposals and outcomes
│   └── buffer_metadata.json          ← Replay buffer state
└── scoring_alignment/
    ├── subnet_plugin_base.py          ← Abstract interface
    ├── run_all_tests.py               ← Generic test runner
    ├── sn44_plugin.py                 ← (optional) SN44 plugin
    └── tests/                         ← Subnet-specific test files
        ├── test_class_mapping.py
        ├── test_frame_alignment.py
        ├── test_confidence_and_gate.py
        ├── test_box_validity_and_rtf.py
        └── test_copy_miner_differentiation.py
```

## Setup for Any Subnet

### 1. Initialise the registry
```bash
python registry/init_registry.py
```

### 2. Fill in subnet_config.json
Edit the template with your subnet's actual values:
- Element IDs and their pillar weights
- `baseline_theta`, `delta_floor`, `beta` from the active manifest
- `ewma_alpha` (SN44: 0.2063, but check your subnet's EWMA settings)
- `deploy_command` — how to push a new model
- `score_read_command` — how to read current scores

### 3. Implement the scoring alignment plugin
Copy `scoring_alignment/subnet_plugin_base.py` as your plugin:
```bash
cp scoring_alignment/subnet_plugin_base.py scoring_alignment/sn{N}_plugin.py
```
Implement the abstract methods — specifically:
- `parse_miner_output()` — exact replica of how the validator parses output
- `score()` — exact replica of the validator's scoring function
- `weight_score()` — exact replica of `Element.weight_score()` from manifest.py
- `get_alignment_checks()` — the specific checks for your subnet

### 4. Run alignment checks
```bash
python scoring_alignment/run_all_tests.py
python scoring_alignment/run_all_tests.py --verbose
python scoring_alignment/run_all_tests.py --update-progress
```

### 5. Start Claude Code
```bash
claude  # from your miner repo root
```
Claude Code reads `CLAUDE.md` automatically and begins the session
start checklist from Section 11.

## Using Claude Code as the Agent

Claude Code **is** the Ralph loop — there is no shell script wrapper.

Start a session:
```
claude
```

Claude Code will:
1. Read `CLAUDE.md` (the agent instructions)
2. Read `subnet_config.json` (the manifest values)
3. Run the session start checklist
4. Determine which loop applies (fast/medium/slow)
5. Take exactly the action appropriate to the current state

The loop runs as long as you keep the session open. Each "iteration"
is one Claude Code invocation that:
- Reads the registry to determine current state
- Checks the window gate (refuses to act if < 5 windows since deployment)
- Runs triage if warranted
- Proposes and validates mutations if conditions are met
- Appends findings to `registry/progress.txt`
- Commits atomically

## What Is and Isn't Generalised

### Generic across all subnets
- Three-loop architecture (fast/medium/slow cadences)
- EWMA window gate (formula is universal)
- Attribution protocol (five confounds are universal)
- Mutation tier taxonomy (concept generalises, specific mutations vary)
- Registry format (`agent_registry.jsonl`, `progress.txt`)
- Copy-miner similarity check (same `are_similar_by_challenges` logic)
- RTF gate check (formula generalises if subnet has real-time requirement)
- Self-improvement loops (shadow calibration, triage prior Bayesian update)

### Subnet-specific (you implement)
- `parse_miner_output()` — output format varies by subnet
- `score()` — scoring function varies by subnet
- `weight_score()` — pillar weights, baseline_theta vary by manifest
- Alignment test cases — what can silently fail varies by subnet
- `subnet_config.json` values — all manifest parameters

### Subnets where scoring is stochastic (LLM judge, human annotation)
For subnets that score using an LLM judge (SN1, SN19) or human
annotation, the `score()` function cannot be locally replicated exactly.
In these cases:
- `score()` should implement a deterministic approximation
- Shadow evaluator accuracy will be lower (~0.60-0.70 even when fresh)
- Set `shadow_accuracy.json` → `base_accuracy` to 0.70 not 0.85
- The mutation validation step is less reliable — require 5+ windows
  of confirmation before treating any mutation as confirmed positive

## SN44 Reference Implementation

The complete SN44 implementation is in `miner_ralph/`:
- 46 tests covering every active scoring path
- Exact replicas of `parse_miner_prediction`, `_evaluate_detection_metrics_at_threshold`, `weight_score`, `calculate_rtf`
- Both elements: `manak0/Detect-Person` and `manak0/Detect-detect-vehicle`
- Zero tests for inactive pillars (iou, count, smoothness, precision, recall)

To use SN44 tests with this framework:
```bash
# Symlink or copy the miner_ralph tests into scoring_alignment/tests/
ln -s ../miner_ralph/tests scoring_alignment/tests
ln -s ../miner_ralph/fixtures scoring_alignment/fixtures
```

## Adapting CLAUDE.md for Your Subnet

CLAUDE.md is generic but contains SN44-specific examples in:
- Section 7 (subnet_config.json template) — update with your values
- Section 4 Step 1 (RTF formula) — update if different
- Section 4 Step 5 (pillar patterns) — update from your subnet's docs

Everything else in CLAUDE.md is subnet-agnostic and should not need changes.

## The Key Insight

Claude Code is the loop. `CLAUDE.md` is the loop specification.
`progress.txt` is the loop state. `subnet_config.json` is the loop parameters.

A new subnet requires:
1. A new `subnet_config.json` (30 minutes of manifest reading)
2. A new `scoring_alignment/plugin.py` (2-4 hours of reading validator source)
3. No changes to `CLAUDE.md`, `registry/`, or the generic test runner

The SN44 implementation took the equivalent of several research sessions
to build from first principles. With this template, a new subnet
implementation takes hours, not sessions.
